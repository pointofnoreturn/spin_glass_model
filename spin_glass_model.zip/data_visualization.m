clear;
[couplings,initialSpins,eqMeanSpins,finalSpins,initial_bg,mean_bg,final_bg]= generateGraph('01_Subject Verb _1e-10_data.mat');
view(initial_bg);
view(mean_bg);
view(final_bg);
